package com.example.anime.dto;

public class RegisterRequest {
    public String username;
    public String email;
    public String password;
    public String confirmPassword;
}
