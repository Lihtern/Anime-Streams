package com.example.anime.controller;

import com.example.anime.dto.RegisterRequest;
import com.example.anime.model.User;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")  // позволяет подключение с фронтенда
public class AuthController {

    private final List<User> users = new ArrayList<>();

    @PostMapping("/register")
    public Map<String, String> register(@RequestBody RegisterRequest request) {
        Map<String, String> response = new HashMap<>();

        if (!request.password.equals(request.confirmPassword)) {
            response.put("status", "error");
            response.put("message", "Пароли не совпадают");
            return response;
        }

        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(request.username)) {
                response.put("status", "error");
                response.put("message", "Пользователь уже существует");
                return response;
            }
        }

        User user = new User(request.username, request.email, request.password);
        users.add(user);

        response.put("status", "ok");
        response.put("message", "Регистрация успешна");
        return response;
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        String password = payload.get("password");

        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(username) &&
                user.getPassword().equals(password)) {
                return Map.of("status", "ok", "message", "Вход выполнен");
            }
        }

        return Map.of("status", "error", "message", "Неверный логин или пароль");
    }
}
