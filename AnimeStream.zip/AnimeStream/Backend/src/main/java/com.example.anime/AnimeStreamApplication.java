package com.example.anime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimeStreamApplication {
    public static void main(String[] args) {
        SpringApplication.run(AnimeStreamApplication.class, args);
    }
}
